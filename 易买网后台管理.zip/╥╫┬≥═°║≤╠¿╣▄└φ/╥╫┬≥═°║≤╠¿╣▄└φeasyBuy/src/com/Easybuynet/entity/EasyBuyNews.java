package com.Easybuynet.entity;

/**
 * Created by rcy on 2019/12/4.
 */
public class EasyBuyNews {

    private int id;
    private String title;//标题
    private String content;//内容
    private String createTime;//创建时间


    public EasyBuyNews() {
    }

    public EasyBuyNews(int id, String title, String content, String createTime) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.createTime = createTime;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }
}
