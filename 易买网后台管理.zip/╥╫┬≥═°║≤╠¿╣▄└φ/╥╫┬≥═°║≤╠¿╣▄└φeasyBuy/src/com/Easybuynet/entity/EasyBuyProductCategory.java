package com.Easybuynet.entity;

/**
 * Created by rcy on 2019/12/4.
 */
public class EasyBuyProductCategory {
    private int id;//主键
    private String name;//名称
    private int parentId;//父级目录id
    private int type;//级别(1:一级 2：二级 3：三级)
    private String iconClass;//图标

    public EasyBuyProductCategory() {
    }

    public EasyBuyProductCategory(int id, String name, int parentId, int type, String iconClass) {
        this.id = id;
        this.name = name;
        this.parentId = parentId;
        this.type = type;
        this.iconClass = iconClass;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getParentId() {
        return parentId;
    }

    public void setParentId(int parentId) {
        this.parentId = parentId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getIconClass() {
        return iconClass;
    }

    public void setIconClass(String iconClass) {
        this.iconClass = iconClass;
    }
}
