package com.Easybuynet.service.impl;

import com.Easybuynet.dao.AdminDao;
import com.Easybuynet.dao.impl.AdminDaoImpl;
import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.service.AdminService;
import com.Easybuynet.util.BaseDaoUtil;
import com.Easybuynet.util.MD5;
import com.Easybuynet.util.Page;
import com.sun.org.apache.bcel.internal.generic.NEW;


import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/12/4.
 */
public class AdminServiceImpl implements AdminService {
    @Override
    public EasyBuyUser Login(EasyBuyUser easyBuyUser) throws SQLException {
        AdminDao adminDao = new AdminDaoImpl(BaseDaoUtil.getConnection());
        String pwd = MD5.getMd5(easyBuyUser.getPassword());
        EasyBuyUser user = adminDao.getAdmin(easyBuyUser.getLoginName(), pwd);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return user;
    }

    @Override
    public int regAdmin(EasyBuyUser easyBuyUser) throws SQLException {
        int i = 100;//默认值
        //获取connection连接对象
        AdminDao adminDao = new AdminDaoImpl(BaseDaoUtil.getConnection());
        if (adminDao.isExit(easyBuyUser.getLoginName())) {
            i = -1;//此用户已经存在
        } else {
            easyBuyUser.setPassword(MD5.getMd5(easyBuyUser.getPassword()));
            i = adminDao.addAdmin(easyBuyUser);//正常添加数据
        }
        //关闭资源
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return i;
    }

    @Override
    public int upAdmin(String password, int id) throws SQLException {
        AdminDao adminDao = new AdminDaoImpl(BaseDaoUtil.getConnection());
        int i = adminDao.upAdmin(password,id);
        return i;
    }

    @Override
    public int delUser(int id) throws SQLException {
        AdminDao adminDao = new AdminDaoImpl(BaseDaoUtil.getConnection());
        int i = adminDao.delAdmin(id);
        return i;
    }
    @Override
    public List<EasyBuyUser> getPageList(int pageIndex, int size, String param) throws SQLException {
        AdminDao adminDao = new AdminDaoImpl(BaseDaoUtil.getConnection());
        List<EasyBuyUser> loginUserList   = adminDao.getPageList(pageIndex, size, param);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return loginUserList;
    }

    @Override
    public Page getAdminPage(Page page, String param) throws SQLException {
        AdminDao adminDao = new AdminDaoImpl(BaseDaoUtil.getConnection());
        int adminCount = adminDao.getAdminCount(param);//得到用户总数
        page.setTotalCount(adminCount);//设置总页数
        if (adminCount > 0) {//有用户存在
            if (page.getCurrPageNo() > page.getTotalCount()) {//当前页数>总页数
                page.setCurrPageNo(page.getTotalPageCount());   //设置当前页为最后一页
            }
            List<EasyBuyUser> list = adminDao.getPageList(page.getCurrPageNo(), page.getPageSize(), param);
            page.setEasyBuyList(list);//存入page对象
        } else { //如果没有数据
            page.setCurrPageNo(0);  //设置页码为0
            page.setEasyBuyList(null);//存入page对象
        }
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return page;
    }


}
