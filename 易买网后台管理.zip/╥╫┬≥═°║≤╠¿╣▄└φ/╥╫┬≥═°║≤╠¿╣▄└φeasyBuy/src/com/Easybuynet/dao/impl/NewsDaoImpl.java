package com.Easybuynet.dao.impl;

import com.Easybuynet.dao.BaseDao;
import com.Easybuynet.dao.NewsDao;
import com.Easybuynet.entity.EasyBuyNews;
import com.Easybuynet.entity.EasyBuyUser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class NewsDaoImpl extends BaseDao implements NewsDao {

    public NewsDaoImpl(Connection conn) {
        super(conn);
    }

    @Override
    public int addNews(EasyBuyNews news) throws SQLException {
        String sql = "insert into easybuy_news(title,content) values(?,?) ";
        Object[] params = {news.getTitle(), news.getContent()};
        int num = super.executeUpdate(sql, params);
        return num;
    }

    @Override
    public int delNews(int id) throws SQLException {
        String sql = "DELETE FROM easybuy_news WHERE id =?";
        Object[] params = {id};
        int num = executeUpdate(sql, params);
        return num;
    }

    @Override
    public int updateNews(EasyBuyNews news) throws SQLException {
        String sql = "UPDATE easybuy_news SET  title=?,content=? where id=?";
        Object[] params = {news.getTitle(), news.getContent(), news.getId()};
        int num = super.executeUpdate(sql, params);
        return num;
    }

    @Override
    public int getNewsCount(String param) throws SQLException {
        ResultSet resultSet = null;
        int i = 0;
        if (param == null || param.equals("")) {
            String sql = "select count(*) from easybuy_news";
            resultSet = super.executeQuery(sql, null);
        } else {
            String sql = "select count(*) from easybuy_news where title like ? or content  like ?";
            Object[] params = {"%" + param + "%", "%" + param + "%"};
            resultSet = super.executeQuery(sql, params);
        }
        if (resultSet.next()) {
            i = resultSet.getInt(1);
        }
        return i;
    }


    @Override
    public List<EasyBuyNews> getPageNews(int pageIndex, int pageSize, String param) throws SQLException {
        List<EasyBuyNews> easyBuyUserList = new ArrayList<>();
        ResultSet resultSet = null;
        if (param == null || param.equals("")) {
            String sql = "select * FROM easybuy_news limit ?, ?";
            Object[] params = {(pageIndex - 1) * pageSize, pageSize};
            resultSet = super.executeQuery(sql, params);
        } else {
            String sql = "select * FROM easybuy_news where loginName like ? or username like ? limit ?, ?";
            Object[] params = {"%" + param + "%", "%" + param + "%", (pageIndex - 1) * pageSize, pageSize};
            resultSet = super.executeQuery(sql, params);
        }
        if (resultSet != null) {
            while (resultSet.next()) {
                EasyBuyNews easyBuyNews = new EasyBuyNews();
                easyBuyNews.setId(resultSet.getInt("id"));
                easyBuyNews.setTitle(resultSet.getString("title"));

                String content=resultSet.getString("content");
                content=content.length()>10?content.substring(0,11)+"...":content;
                easyBuyNews.setContent(content);
                easyBuyNews.setCreateTime(resultSet.getString("createTime"));
                easyBuyUserList.add(easyBuyNews);
            }
        }
        return easyBuyUserList;
    }
}
