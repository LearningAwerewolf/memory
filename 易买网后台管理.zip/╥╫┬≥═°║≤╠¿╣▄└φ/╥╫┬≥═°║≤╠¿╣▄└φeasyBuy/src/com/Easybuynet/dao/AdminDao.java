package com.Easybuynet.dao;

import com.Easybuynet.entity.EasyBuyUser;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by rcy on 2019/12/4.
 */
public interface AdminDao {
    /**
     * 查询用户
     *
     * @return
     * @throws SQLException
     */
    public EasyBuyUser getAdmin(String loginName, String password) throws SQLException;

    /**
     * 添加
     *
     * @return
     */
    public int addAdmin(EasyBuyUser easyBuyUser) throws SQLException;

    /**
     * 删除
     *
     * @return
     * @throws SQLException
     */
    public int delAdmin(int id) throws SQLException;

    /**
     * 修改
     *
     * @return
     * @throws SQLException
     */

    public int upAdmin(String password, int id) throws SQLException;


    /**
     * 查重
     *
     * @return
     */
    public boolean isExit(String loginName) throws SQLException;

    /**
     * 通过关键字（参数）查询用户
     *
     * @return
     * @throws SQLException
     */
    public int getAdminCount(String param) throws SQLException;

    /**
     * 获取用户列表
     *
     * @param pageIndex
     * @param size
     * @param param
     * @return
     * @throws SQLException
     */
    public List<EasyBuyUser> getPageList(int pageIndex, int size, String param) throws SQLException;


}
