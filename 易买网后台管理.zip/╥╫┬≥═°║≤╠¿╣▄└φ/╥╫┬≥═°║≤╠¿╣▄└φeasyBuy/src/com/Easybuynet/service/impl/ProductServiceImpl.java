package com.Easybuynet.service.impl;

import com.Easybuynet.dao.AdminDao;
import com.Easybuynet.dao.ProductDao;
import com.Easybuynet.dao.impl.AdminDaoImpl;
import com.Easybuynet.dao.impl.ProductDaoImpl;
import com.Easybuynet.entity.EasyBuyProduct;
import com.Easybuynet.entity.EasyBuyProductCategory;
import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.service.ProductService;
import com.Easybuynet.util.BaseDaoUtil;
import com.Easybuynet.util.Page;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/12/10.
 */
public class ProductServiceImpl implements ProductService {
    @Override
    public Page getProductPage(Page page, String param) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        int productCount = productDao.getProCount(param);//得到用户总数
        page.setTotalCount(productCount);//设置总页数

        if (productCount > 0) {//有用户存在
            if (page.getCurrPageNo() > page.getTotalCount()) {//当前页数>总页数
                page.setCurrPageNo(page.getTotalPageCount());   //设置当前页为最后一页
            }
            List<EasyBuyProduct> list = productDao.getPagePro(page.getCurrPageNo(), page.getPageSize(), param);
            page.setEasyBuyList(list);//存入page对象
        } else { //如果没有数据
            page.setCurrPageNo(0);  //设置页码为0
            page.setEasyBuyList(null);//存入page对象
        }
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return page;
    }

    @Override
    public int delpro(int id) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        int i = productDao.delpro(id);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return i;
    }

    @Override
    public List<EasyBuyProductCategory> getCategoryByType(int type) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        List<EasyBuyProductCategory> list = productDao.getCategoryByType(type);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return list;
    }

    @Override
    public List<EasyBuyProductCategory> getCategoryByParentId(int parentId) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        List<EasyBuyProductCategory> list = productDao.getCategoryByParentId(parentId);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return list;
    }

    @Override
    public int addProduct(EasyBuyProduct easyBuyProduct) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        int i = productDao.addProduct(easyBuyProduct);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return i;
    }

    @Override
    public EasyBuyProduct getProductById(int pid) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        EasyBuyProduct easyBuyProduct = productDao.getProductById(pid);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return easyBuyProduct;
    }

    @Override
    public int updateProduct(EasyBuyProduct product) throws SQLException {
        ProductDao productDao = new ProductDaoImpl(BaseDaoUtil.getConnection());
        int i = productDao.updateProduct(product);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return i;
    }
}
