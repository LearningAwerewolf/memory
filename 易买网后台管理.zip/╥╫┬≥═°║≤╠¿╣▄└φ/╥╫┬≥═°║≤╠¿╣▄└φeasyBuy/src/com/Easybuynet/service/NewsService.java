package com.Easybuynet.service;

import com.Easybuynet.entity.EasyBuyNews;
import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.util.Page;

import java.sql.SQLException;
import java.util.List;

public interface NewsService {
    /**
     * 添加新闻
     *
     * @param news
     * @return
     * @throws SQLException
     */
    public int addNews(EasyBuyNews news) throws SQLException;

    /**
     * 删除新闻
     *
     * @param id
     * @return
     * @throws SQLException
     */
    public int delNews(int id) throws SQLException;

    /**
     * 修改新闻
     *
     * @param news
     * @return
     * @throws SQLException
     */
    public int updateNews(EasyBuyNews news) throws SQLException;


    /**
     * 根据页码和每页数据量查询列表
     *
     * @param pageIndex
     * @param size
     * @return
     * @throws SQLException
     */
    public List<EasyBuyNews> getPageNews(int pageIndex, int size, String param) throws SQLException;


    public Page getNewsPage(Page page, String param) throws SQLException;


}
