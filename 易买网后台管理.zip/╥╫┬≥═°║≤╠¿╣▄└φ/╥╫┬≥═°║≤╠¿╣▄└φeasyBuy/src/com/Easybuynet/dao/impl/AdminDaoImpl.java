package com.Easybuynet.dao.impl;

import com.Easybuynet.dao.AdminDao;
import com.Easybuynet.dao.BaseDao;
import com.Easybuynet.entity.EasyBuyUser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/12/4.
 */
public class AdminDaoImpl extends BaseDao implements AdminDao {

    public AdminDaoImpl(Connection conn) {
        super(conn);
    }

    EasyBuyUser easyBuyUser = null;
    List<EasyBuyUser> easyBuyUserList = null;

    @Override
    public EasyBuyUser getAdmin(String loginName, String password) throws SQLException {
        String sql = "select * from easybuy_user where loginName=? and password=?";
        Object[] params = {loginName, password};
        ResultSet resultSet = super.executeQuery(sql, params);
        if (resultSet.next()) {
            easyBuyUser = new EasyBuyUser();
            easyBuyUser.setId(resultSet.getInt("id"));
            easyBuyUser.setPassword(resultSet.getString("password"));
            easyBuyUser.setLoginName(resultSet.getString("loginName"));
            easyBuyUser.setUserName(resultSet.getString("username"));
        }
        return easyBuyUser;
    }

    @Override
    public int addAdmin(EasyBuyUser easyBuyUser) throws SQLException {
        String sql = "insert into easybuy_user(loginName,userName,password) values(?,?,?) ";
        Object[] params = {easyBuyUser.getLoginName(), easyBuyUser.getUserName(), easyBuyUser.getPassword()};
        int num = super.executeUpdate(sql, params);
        return num;

    }


    @Override
    public int delAdmin(int id) throws SQLException {
        String sql = "DELETE FROM easybuy_user WHERE id =?";
        Object[] params = {id};
        int num = executeUpdate(sql, params);
        return num;
    }

    @Override
    public int upAdmin(String password, int id) throws SQLException {
        String sql = "UPDATE easybuy_user SET  password=? where id=?";
        Object[] params = {password, id};
        int num = super.executeUpdate(sql, params);
        return num;
    }

    @Override
    public boolean isExit(String loginName) throws SQLException {
        Boolean flage = false;
        String sql = "select * from easybuy_user where loginName=?";
        Object[] params = {loginName};
        ResultSet resultSet = super.executeQuery(sql, params);
        if (resultSet.next()) {
            flage = true;
        }
        return flage;
    }

    @Override
    public int getAdminCount(String param) throws SQLException {
        ResultSet resultSet = null;
        int i = 0;
        if (param == null || param.equals("")) {
            String sql = "select count(*) from easybuy_user";
            resultSet = super.executeQuery(sql, null);
        } else {
            String sql = "select count(*) from easybuy_user where loginName like ? or username  like ?";
            Object[] params = {"%" + param + "%", "%" + param + "%"};
            resultSet = super.executeQuery(sql, params);
        }
        if (resultSet.next()) {
            i = resultSet.getInt(1);
        }
        return i;
    }

    @Override
    public List<EasyBuyUser> getPageList(int pageIndex, int size, String param) throws SQLException {
        easyBuyUserList = new ArrayList<>();
        ResultSet resultSet = null;
        if (param == null || param.equals("")) {
            String sql = "select * FROM easybuy_user limit ?, ?";
            Object[] params = {(pageIndex - 1) * size, size};
            resultSet = super.executeQuery(sql, params);
        } else {
            String sql = "select * FROM easybuy_user where loginName like ? or username like ? limit ?, ?";
            Object[] params = {"%" + param + "%", "%" + param + "%", (pageIndex - 1) * size, size};
            resultSet = super.executeQuery(sql, params);
        }
        if (resultSet != null) {
            while (resultSet.next()) {
                easyBuyUser = new EasyBuyUser();
                easyBuyUser.setId(resultSet.getInt("id"));
                easyBuyUser.setPassword(resultSet.getString("password"));
                easyBuyUser.setLoginName(resultSet.getString("loginName"));
                easyBuyUser.setUserName(resultSet.getString("username"));
                easyBuyUserList.add(easyBuyUser);
            }
        }
        return easyBuyUserList;
    }


}
