package com.Easybuynet.servlet;

import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.service.AdminService;
import com.Easybuynet.service.impl.AdminServiceImpl;
import com.Easybuynet.util.MD5;
import com.Easybuynet.util.Page;
import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by rcy on 2019/12/4.
 */
public class AdminServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String flag = req.getParameter("flag");
        AdminService adminService = new AdminServiceImpl();
        PrintWriter out = resp.getWriter();
        if (flag.equals("login")) {
            EasyBuyUser easyBuyUser = new EasyBuyUser();
            easyBuyUser.setLoginName(req.getParameter("txtUserName"));
            easyBuyUser.setPassword(req.getParameter("txtPwd"));
            EasyBuyUser loginuser = null;
            try {
                loginuser = adminService.Login(easyBuyUser);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if (loginuser == null) {
                out.print(0);
            } else {
                req.getSession().setAttribute("loginUser", loginuser);
                out.print(1);
            }
        } else if (flag.equals("logout")) {
            req.getSession().removeAttribute("loginUser");
            resp.sendRedirect("login.html");
        } else if (flag.equals("add")) {
            EasyBuyUser easyBuyUser = new EasyBuyUser();
            easyBuyUser.setLoginName(req.getParameter("txtALoginName"));
            easyBuyUser.setUserName(req.getParameter("txtAUserName"));
            easyBuyUser.setPassword(req.getParameter("txtAPassWord"));
            int i = 0;
            try {
                i = adminService.regAdmin(easyBuyUser);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            out.print(i);
        } else if (flag.equals("list")) {
            //先获取集合
            String param = req.getParameter("param");
            String pageindex = req.getParameter("pageindex");
            if (pageindex == null || pageindex.equals("")) {
                pageindex = "1";
            }
            int pindex = Integer.parseInt(pageindex);
            if (pindex < 0) {
                pindex = 1;
            }
            Page pageParam = new Page();
            pageParam.setCurrPageNo(pindex);
            Page myPage = null;
            try {
                myPage = adminService.getAdminPage(pageParam, param);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String json = JSON.toJSONString(myPage);
            out.println(json);
        } else if (flag.equals("del")) {
            //先获取集合
            int id = Integer.parseInt(req.getParameter("uid"));
            int i = 0;
            try {
                i = adminService.delUser(id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            out.println(i);
        } else if (flag.equals("toup")) {


        } else if (flag.equals("up")) {

        } else if (flag.equals("uppwd")) {
            //获取修改后的密码
            EasyBuyUser loginuser = (EasyBuyUser) req.getSession().getAttribute("loginUser");
            loginuser.setPassword(MD5.getMd5(req.getParameter("newpwd")));
            System.out.println(MD5.getMd5(req.getParameter("newpwd")));
            int i = 0;
            try {
                i = adminService.upAdmin(loginuser.getPassword(), loginuser.getId());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            out.println(i);
        } else if (flag.equals("ispwd")) {
            //从页面请求拿到原密码
            EasyBuyUser loginuser = (EasyBuyUser) req.getSession().getAttribute("loginUser");
            String oldPwd = loginuser.getPassword();
            int tie = -1;//默认值
            if (oldPwd.equals(MD5.getMd5(req.getParameter("txtoldPassWord")))) {//如果原密码和登陆的密码一样就为其进行更改密码
                out.println(1);
            } else {//如果原密码和登陆的密码不一样,就给他一个提示
                out.println(0);
            }
        }
        out.flush();
        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
