package com.Easybuynet.dao.impl;

import com.Easybuynet.dao.BaseDao;
import com.Easybuynet.dao.ProductDao;
import com.Easybuynet.entity.EasyBuyProduct;
import com.Easybuynet.entity.EasyBuyProductCategory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Administrator on 2019/12/10.
 */
public class ProductDaoImpl extends BaseDao implements ProductDao {
    public ProductDaoImpl(Connection conn) {
        super(conn);
    }

    ResultSet resultSet = null;
    List<EasyBuyProduct> list = null;

    @Override
    public int getProCount(String param) throws SQLException {

        int i = 0;
        if (param == null || param.equals("")) {
            String sql = "select count(*) from easybuy_product";
            resultSet = super.executeQuery(sql, null);
        } else {
            String sql = "select count(*) from easybuy_product where name like ?";
            Object[] params = {"%" + param + "%"};
            resultSet = super.executeQuery(sql, params);
        }
        if (resultSet != null && resultSet.next()) {
            i = resultSet.getInt(1);
        }
        return i;
    }

    @Override
    public List<EasyBuyProduct> getPagePro(int pageIndex, int size, String param) throws SQLException {
        list = new ArrayList<EasyBuyProduct>();
        if (param == null || param.equals("")) {
            String sql = "SELECT pro.id, pro.name,description,price,stock,categoryLevel1Id,categoryLevel2Id,categoryLevel3Id,c1.name 'category1',c2.name 'category2',c3.name 'category3'\n" +
                    "FROM easybuy_product pro\n" +
                    "LEFT JOIN easybuy_product_category c1\n" +
                    "ON c1.id = pro.categoryLevel1Id\n" +
                    "LEFT JOIN easybuy_product_category c2\n" +
                    "ON c2.id = pro.categoryLevel2Id\n" +
                    "LEFT JOIN easybuy_product_category c3\n" +
                    "ON c3.id = pro.categoryLevel3Id\n" +
                    "LIMIT ?,?";
            Object[] params = {(pageIndex - 1) * size, size};
            resultSet = super.executeQuery(sql, params);
        } else {
            String sql = "SELECT pro.id, pro.name,description,price,stock,categoryLevel1Id,categoryLevel2Id,categoryLevel3Id,c1.name 'category1',c2.name 'category2',c3.name 'category3'\n" +
                    "FROM easybuy_product pro\n" +
                    "LEFT JOIN easybuy_product_category c1\n" +
                    "ON c1.id = pro.categoryLevel1Id\n" +
                    "LEFT JOIN easybuy_product_category c2\n" +
                    "ON c2.id = pro.categoryLevel2Id\n" +
                    "LEFT JOIN easybuy_product_category c3\n" +
                    "ON c3.id = pro.categoryLevel3Id\n" +
                    "WHERE pro.name LIKE ?\n" +
                    "LIMIT ?,?";
            Object[] params = {"%" + param + "%", pageIndex, size};
            resultSet = super.executeQuery(sql, params);
        }
        if (resultSet != null) {
            while (resultSet.next()) {
                EasyBuyProduct easyBuyProduct = new EasyBuyProduct();
                easyBuyProduct.setCategory1(resultSet.getString("category1"));
                easyBuyProduct.setCategory2(resultSet.getString("category2"));
                easyBuyProduct.setCategory3(resultSet.getString("category3"));
                easyBuyProduct.setCategoryLevel1Id(resultSet.getInt("categoryLevel1Id"));
                easyBuyProduct.setCategoryLevel2Id(resultSet.getInt("categoryLevel2Id"));
                easyBuyProduct.setCategoryLevel3Id(resultSet.getInt("categoryLevel3Id"));
                easyBuyProduct.setDescription(resultSet.getString("description"));
                easyBuyProduct.setId(resultSet.getInt("id"));
                easyBuyProduct.setName(resultSet.getString("name"));
                easyBuyProduct.setPrice(resultSet.getInt("price"));
                easyBuyProduct.setStock(resultSet.getInt("stock"));
                list.add(easyBuyProduct);
            }
        }
        return list;
    }

    @Override
    public int delpro(int id) throws SQLException {
        String sql = "DELETE FROM easybuy_product WHERE id =?";
        Object[] params = {id};
        int num = executeUpdate(sql, params);
        return num;
    }

    @Override
    public List<EasyBuyProductCategory> getCategoryByType(int type) throws SQLException {
        List<EasyBuyProductCategory> list = new ArrayList<>();
        String sql = "select  * from easybuy_product_category where type=?";
        Object[] params = {type};
        resultSet = super.executeQuery(sql, params);
        if (resultSet != null) {
            while (resultSet.next()) {
                EasyBuyProductCategory easyBuyProductCategory = new EasyBuyProductCategory();
                easyBuyProductCategory.setId(resultSet.getInt("id"));
                easyBuyProductCategory.setName(resultSet.getString("name"));
                easyBuyProductCategory.setParentId(resultSet.getInt("parentId"));
                easyBuyProductCategory.setIconClass(resultSet.getString("iconClass"));
                easyBuyProductCategory.setType(resultSet.getInt("type"));
                list.add(easyBuyProductCategory);
            }
        }
        return list;
    }

    @Override
    public List<EasyBuyProductCategory> getCategoryByParentId(int parentId) throws SQLException {
        List<EasyBuyProductCategory> list = new ArrayList<>();
        String sql = "select  * from easybuy_product_category where parentId=?";
        Object[] params = {parentId};
        resultSet = super.executeQuery(sql, params);
        if (resultSet != null) {
            while (resultSet.next()) {
                EasyBuyProductCategory easyBuyProductCategory = new EasyBuyProductCategory();
                easyBuyProductCategory.setId(resultSet.getInt("id"));
                easyBuyProductCategory.setName(resultSet.getString("name"));
                easyBuyProductCategory.setParentId(resultSet.getInt("parentId"));
                easyBuyProductCategory.setIconClass(resultSet.getString("iconClass"));
                easyBuyProductCategory.setType(resultSet.getInt("type"));
                list.add(easyBuyProductCategory);
            }
        }
        return list;
    }

    @Override
    public int addProduct(EasyBuyProduct easyBuyProduct) throws SQLException {
        String sql = "INSERT into easybuy_product (name,price,stock,isDelete,fileName,description,categoryLevel1Id,categoryLevel2Id,categoryLevel3Id) values(?,?,?,?,?,?,?,?,?)";
        Object[] params = {easyBuyProduct.getName(), easyBuyProduct.getPrice(), easyBuyProduct.getStock(), easyBuyProduct.getIsDelete(), easyBuyProduct.getFileName(), easyBuyProduct.getDescription(), easyBuyProduct.getCategoryLevel1Id(), easyBuyProduct.getCategoryLevel2Id(), easyBuyProduct.getCategoryLevel3Id()};
        int num = super.executeUpdate(sql, params);
        return num;
    }

    @Override
    public EasyBuyProduct getProductById(int pid) throws SQLException {
        EasyBuyProduct easyBuyProduct = null;
        String sql = "SELECT pro.id, pro.name,description,price,stock,categoryLevel1Id,categoryLevel2Id,categoryLevel3Id,c1.name 'category1',c2.name 'category2',c3.name 'category3'\n" +
                "FROM easybuy_product pro\n" +
                "LEFT JOIN easybuy_product_category c1\n" +
                "ON c1.id = pro.categoryLevel1Id\n" +
                "LEFT JOIN easybuy_product_category c2\n" +
                "ON c2.id = pro.categoryLevel2Id\n" +
                "LEFT JOIN easybuy_product_category c3\n" +
                "ON c3.id = pro.categoryLevel3Id\n" +
                "where pro.id=?";
        Object[] params = {pid};
        resultSet = super.executeQuery(sql, params);
        if (resultSet != null && resultSet.next()) {
            easyBuyProduct = new EasyBuyProduct();
            easyBuyProduct.setCategory1(resultSet.getString("category1"));
            easyBuyProduct.setCategory2(resultSet.getString("category2"));
            easyBuyProduct.setCategory3(resultSet.getString("category3"));
            easyBuyProduct.setCategoryLevel1Id(resultSet.getInt("categoryLevel1Id"));
            easyBuyProduct.setCategoryLevel2Id(resultSet.getInt("categoryLevel2Id"));
            easyBuyProduct.setCategoryLevel3Id(resultSet.getInt("categoryLevel3Id"));
            easyBuyProduct.setDescription(resultSet.getString("description"));
            easyBuyProduct.setId(resultSet.getInt("id"));
            easyBuyProduct.setName(resultSet.getString("name"));
            easyBuyProduct.setPrice(resultSet.getInt("price"));
            easyBuyProduct.setStock(resultSet.getInt("stock"));
        }
        return easyBuyProduct;
    }

    @Override
    public int updateProduct(EasyBuyProduct product) throws SQLException {
        String sql = "UPDATE easybuy_product SET\n" +
                "description=?,\n" +
                "name=?,\n" +
                "price=?,\n" +
                "stock=?,\n" +
                "categoryLevel1Id=?,\n" +
                "categoryLevel2Id=?,\n" +
                "categoryLevel3Id=?\n" +
                "WHERE id=?";
        Object[] params = { product.getDescription(),
                product.getName(),
                product.getPrice(),
                product.getStock(),
                product.getCategoryLevel1Id(),
                product.getCategoryLevel2Id(),
                product.getCategoryLevel3Id(),
                product.getId()};
        int num = super.executeUpdate(sql, params);
        return num;
    }
}
