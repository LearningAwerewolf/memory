package com.Easybuynet.service;

import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.util.Page;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by Administrator on 2019/12/4.
 */
public interface AdminService {
    public EasyBuyUser Login(EasyBuyUser easyBuyUser) throws SQLException;

    public int regAdmin(EasyBuyUser easyBuyUser) throws SQLException;

    public int upAdmin(String password,int id) throws SQLException;

    public List<EasyBuyUser> getPageList(int pageIndex, int size, String param) throws SQLException;

    public Page getAdminPage(Page page, String param) throws SQLException;

    public int delUser(int id) throws SQLException;

}
