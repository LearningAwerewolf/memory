package com.Easybuynet.service.impl;


import com.Easybuynet.dao.AdminDao;
import com.Easybuynet.dao.NewsDao;
import com.Easybuynet.dao.impl.AdminDaoImpl;
import com.Easybuynet.dao.impl.NewsDaoImpl;
import com.Easybuynet.entity.EasyBuyNews;
import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.service.NewsService;
import com.Easybuynet.util.BaseDaoUtil;
import com.Easybuynet.util.Page;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by Administrator on 2019/12/10.
 */
public class NewsServiceImpl implements NewsService {
    @Override
    public int addNews(EasyBuyNews news) throws SQLException {
        NewsDao newsDao = new NewsDaoImpl(BaseDaoUtil.getConnection());
        int row = newsDao.addNews(news);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);//关
        return row;
    }

    @Override
    public int delNews(int id) throws SQLException {
        NewsDao newsDao = new NewsDaoImpl(BaseDaoUtil.getConnection());
        int row = newsDao.delNews(id);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);//关
        return row;
    }

    @Override
    public int updateNews(EasyBuyNews news) throws SQLException {
        NewsDao newsDao = new NewsDaoImpl(BaseDaoUtil.getConnection());
        int row = newsDao.updateNews(news);
        return row;
    }


    @Override
    public List<EasyBuyNews> getPageNews(int pageIndex, int size, String param) throws SQLException {
        NewsDao newsDao = new NewsDaoImpl(BaseDaoUtil.getConnection());
        List<EasyBuyNews> list = newsDao.getPageNews(pageIndex, size, param);
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return list;
    }

    @Override
    public Page getNewsPage(Page page, String param) throws SQLException {
        NewsDao newsDao = new NewsDaoImpl(BaseDaoUtil.getConnection());
        int adminCount = newsDao.getNewsCount(param);//得到用户总数
        page.setTotalCount(adminCount);//设置总页数
        if (adminCount > 0) {//有用户存在
            if (page.getCurrPageNo() > page.getTotalCount()) {//当前页数>总页数
                page.setCurrPageNo(page.getTotalPageCount());   //设置当前页为最后一页
            }
            List<EasyBuyNews> list = newsDao.getPageNews(page.getCurrPageNo(), page.getPageSize(), param);
            page.setEasyBuyList(list);//存入page对象
        } else { //如果没有数据
            page.setCurrPageNo(0);  //设置页码为0
            page.setEasyBuyList(null);//存入page对象
        }
        BaseDaoUtil.colseAll(BaseDaoUtil.getConnection(), null, null);
        return page;
    }
}
