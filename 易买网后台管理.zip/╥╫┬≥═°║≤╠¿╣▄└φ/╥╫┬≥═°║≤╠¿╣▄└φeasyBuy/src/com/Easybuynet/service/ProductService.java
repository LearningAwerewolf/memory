package com.Easybuynet.service;

import com.Easybuynet.entity.EasyBuyProduct;
import com.Easybuynet.entity.EasyBuyProductCategory;
import com.Easybuynet.util.Page;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by Administrator on 2019/12/10.
 */
public interface ProductService {
    public Page getProductPage(Page page, String param) throws SQLException;

    public int delpro(int id) throws SQLException;

    /**
     * 通过Type获取商品类别
     *
     * @param type
     * @return
     */
    public List<EasyBuyProductCategory> getCategoryByType(int type) throws SQLException;

    /**
     * 通过ParentId获取商品类别
     *
     * @param parentId
     * @return
     */
    public List<EasyBuyProductCategory> getCategoryByParentId(int parentId) throws SQLException;

    /**
     * 添加商品
     *
     * @param easyBuyProduct
     * @return
     */
    public int addProduct(EasyBuyProduct easyBuyProduct) throws SQLException;

    /***
     *去编辑时候使用的
     *通过商品Id查询商品信息
     **/
    public EasyBuyProduct getProductById(int pid) throws SQLException;

    /***
     *
     *修改页面，保存使用的
     *通过id确认要修改商品
     *名字，价格，库存，类别1，类别2，类别3，描述
     */
    public int updateProduct(EasyBuyProduct product) throws SQLException;
}
