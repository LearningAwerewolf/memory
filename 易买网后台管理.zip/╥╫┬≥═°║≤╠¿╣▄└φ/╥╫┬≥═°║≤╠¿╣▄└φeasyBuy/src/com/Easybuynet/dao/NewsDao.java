package com.Easybuynet.dao;

import com.Easybuynet.entity.EasyBuyNews;

import java.sql.SQLException;
import java.util.List;

/**
 * Created by rcy on 2019/12/4.
 */
public interface NewsDao {


    /**
     * 添加新闻
     *
     * @param news
     * @return
     * @throws SQLException
     */
    public int addNews(EasyBuyNews news) throws SQLException;

    /**
     * 删除新闻
     *
     * @param id
     * @return
     * @throws SQLException
     */
    public int delNews(int id) throws SQLException;

    /**
     * 修改新闻
     *
     * @param news
     * @return
     * @throws SQLException
     */
    public int updateNews(EasyBuyNews news) throws SQLException;


    /**
     * 通过关键字（参数）查询新闻
     *
     * @return
     * @throws SQLException
     */
    public int getNewsCount(String param) throws SQLException;

    /**
     * 根据页码和每页数据量查询列表
     *
     * @param pageNo
     * @param pageSize
     * @return
     * @throws SQLException
     */
    public List<EasyBuyNews> getPageNews(int pageNo, int pageSize, String param) throws SQLException;

}
