package com.Easybuynet.servlet;


import com.Easybuynet.entity.EasyBuyProduct;
import com.Easybuynet.entity.EasyBuyProductCategory;
import com.Easybuynet.service.ProductService;
import com.Easybuynet.service.impl.ProductServiceImpl;
import com.Easybuynet.util.Page;
import com.alibaba.fastjson.JSON;
import com.sun.org.apache.bcel.internal.generic.NEW;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

/**
 * Created by Administrator on 2019/12/10.
 */
public class ProductServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String flag = req.getParameter("flag");
        ProductService productService = new ProductServiceImpl();
        PrintWriter out = resp.getWriter();
        if (flag.equals("list")) {
            //先获取集合
            String param = req.getParameter("param");
            String pageindex = req.getParameter("pageindex");
            if (pageindex == null || pageindex.equals("")) {
                pageindex = "1";
            }
            int pindex = Integer.parseInt(pageindex);
            if (pindex < 0) {
                pindex = 1;
            }
            Page pageParam = new Page();
            pageParam.setCurrPageNo(pindex);
            pageParam.setPageSize(5);

            Page myPage = null;
            try {
                myPage = productService.getProductPage(pageParam, param);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String json = JSON.toJSONString(myPage);
            out.println(json);
        } else if (flag.equals("del")) {
            //先获取集合
            int id = Integer.parseInt(req.getParameter("uid"));
            int i = 0;
            try {
                i = productService.delpro(id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            out.println(i);
        } else if (flag.equals("c1")) {
            List<EasyBuyProductCategory> list = null;
            try {
                list = productService.getCategoryByType(1);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String json = JSON.toJSONString(list);
            out.println(json);
        } else if (flag.equals("ch")) {
            List<EasyBuyProductCategory> list = null;
            try {
                list = productService.getCategoryByParentId(Integer.parseInt(req.getParameter("id")));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String json = JSON.toJSONString(list);
            out.println(json);
        } else if (flag.equals("add")) {
            //创建商品对象
            EasyBuyProduct easyBuyProduct = new EasyBuyProduct();
            //请求信息中的内容是否是multipart类型
            boolean isMultipart = ServletFileUpload.isMultipartContent(req);
            //储存路径的设置（服务器文件系统上的绝对文件路径?
            String uploadFilePath = req.getSession().getServletContext().getRealPath("/productImgUp");
            //isMultipart是true了才继续
            if (isMultipart) {
                FileItemFactory factory = new DiskFileItemFactory();
                ServletFileUpload upload = new ServletFileUpload(factory);
                //解析form表单中所有文件
                try {
                    List<FileItem> items = upload.parseRequest(req);//获取所有的文件【普通的，文件的】
                    Iterator<FileItem> iter = items.iterator();//迭代器
                    while (iter.hasNext()) {//依次处理每个文件
                        FileItem item = (FileItem) iter.next();
                        if (item.isFormField()) {  //普通表单字段
                            String fieldName = item.getFieldName();   //表单字段的name属性值
                            //根据文件名，也就是表单中的name的值，给商品赋值
                            if (fieldName.equals("txtName")) {//商品名称
                                easyBuyProduct.setName(item.getString());
                            } else if (fieldName.equals("category1")) {//类别1
                                easyBuyProduct.setCategoryLevel1Id(Integer.parseInt(item.getString()));
                            } else if (fieldName.equals("category2")) {//类别2
                                easyBuyProduct.setCategoryLevel2Id(Integer.parseInt(item.getString()));
                            } else if (fieldName.equals("category3")) {//类别3
                                easyBuyProduct.setCategoryLevel3Id(Integer.parseInt(item.getString()));
                            } else if (fieldName.equals("txtPrice")) {//价格
                                easyBuyProduct.setPrice(Integer.parseInt(item.getString()));
                            } else if (fieldName.equals("txtDescription")) {//描述
                                easyBuyProduct.setDescription(item.getString());
                            } else if (fieldName.equals("txtStock")) {//库存
                                easyBuyProduct.setStock(Integer.parseInt(item.getString()));
                            }
                            //                        else if (fieldName.equals("txtFileName")) {//文件名称【图片】
                            //                            easyBuyProduct.setFileName(item.getString());
                            //                        }
                        } else {//文件表单字段
                            String itemFileName = item.getName();//得到文件名
                            if (itemFileName != null && !itemFileName.equals("")) {//判断文件名是否为空
                                File fullFile = new File(item.getName());//得到上传文件对象
                                File saveFile = new File(uploadFilePath, fullFile.getName());
                                easyBuyProduct.setFileName(fullFile.getName());
                                item.write(saveFile);

                            }
                        }
                    }
                    productService.addProduct(easyBuyProduct);
                    resp.sendRedirect("product/productlist.jsp");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } else if (flag.equals("toup")) {
            String id = req.getParameter("id");
            EasyBuyProduct easyBuyProduct = null;
            try {
                easyBuyProduct = productService.getProductById(Integer.parseInt(id));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            req.setAttribute("easyBuyProduct", easyBuyProduct);
            req.getRequestDispatcher("product/upproduct.jsp").forward(req, resp);
        } else if (flag.equals("up")) {
            EasyBuyProduct easyBuyProduct = new EasyBuyProduct();
            easyBuyProduct.setId(Integer.parseInt(req.getParameter("id")));
            easyBuyProduct.setName(req.getParameter("txtName"));
            easyBuyProduct.setCategoryLevel1Id(Integer.parseInt(req.getParameter("category1")));
            easyBuyProduct.setCategoryLevel2Id(Integer.parseInt(req.getParameter("category2")));
            easyBuyProduct.setCategoryLevel3Id(Integer.parseInt(req.getParameter("category3")));
            easyBuyProduct.setPrice(Integer.parseInt(req.getParameter("txtPrice")));
            easyBuyProduct.setStock(Integer.parseInt(req.getParameter("txtStock")));
            easyBuyProduct.setDescription(req.getParameter("txtDescription"));
            try {
                productService.updateProduct(easyBuyProduct);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            resp.sendRedirect("product/productlist.jsp");
        }
        out.flush();
        out.close();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
