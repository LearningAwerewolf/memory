package com.Easybuynet.servlet;

import com.Easybuynet.entity.EasyBuyNews;
import com.Easybuynet.entity.EasyBuyUser;
import com.Easybuynet.service.AdminService;
import com.Easybuynet.service.NewsService;
import com.Easybuynet.service.impl.AdminServiceImpl;
import com.Easybuynet.service.impl.NewsServiceImpl;
import com.Easybuynet.util.Page;
import com.alibaba.fastjson.JSON;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

/**
 * Created by Administrator on 2019/12/10.
 */
public class NewsServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String flag = req.getParameter("flag");
        NewsService newsService = new NewsServiceImpl();
        PrintWriter out = resp.getWriter();
        if (flag.equals("add")) {
            EasyBuyNews easyBuyNews = new EasyBuyNews();
            easyBuyNews.setContent(req.getParameter("newsCountent"));
            easyBuyNews.setTitle(req.getParameter("newstitle"));
            int i = 0;
            try {
                i = newsService.addNews(easyBuyNews);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            out.print(i);
        }else if (flag.equals("list")) {
            //先获取集合
            String param = req.getParameter("param");
            String pageindex = req.getParameter("pageindex");
            if (pageindex == null || pageindex.equals("")) {
                pageindex = "1";
            }
            int pindex = Integer.parseInt(pageindex);
            if (pindex < 0) {
                pindex = 1;
            }
            Page pageParam = new Page();
            pageParam.setCurrPageNo(pindex);
            Page myPage = null;
            try {
                myPage = newsService.getNewsPage(pageParam, param);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String json = JSON.toJSONString(myPage);
            out.println(json);
        }else if (flag.equals("del")) {
            //先获取集合
            int id = Integer.parseInt(req.getParameter("uid"));
            int i = 0;
            try {
                i = newsService.delNews(id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            out.println(i);
        }

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
